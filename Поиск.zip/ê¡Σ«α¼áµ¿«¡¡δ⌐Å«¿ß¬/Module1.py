import json
import re
import glob
import pymorphy2
from nltk.corpus import stopwords
morph = pymorphy2.MorphAnalyzer()
import pickle

#Функция удаления стоп-слов, проведения лематизации и удаление всех символов
def clear_data(data):
    data = re.sub(r'[\W_]+'," ", data)
    data = data.lower().split(" ")
    clear = [morph.parse(i)[0].normal_form for i in data if i not in stopwords.words('russian')]
    return clear
index = {}
filename = glob.glob ("../ИнформационныйПоискФайлы/*.json")
for i in filename:
    with open(i) as json_data:
        d = json.load(json_data)
        news = d["title"]+" "+ d["text"]
        index[i[28:]] =set(clear_data(news))
#Построение инвертированного индекса
def invert_index(doc):
    FileIndex={}
    for key in doc:
        for word in doc[key]:
            if word in FileIndex.keys():
                FileIndex[word].add(key)
            else:
                FileIndex[word]=set()
                FileIndex[word].add(key)
    return (FileIndex)
result_index = invert_index(index)

with open("invert_index.pickle","wb") as file:
    pickle.dump(result_index, file)
