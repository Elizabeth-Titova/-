import re
import pymorphy2
from nltk.corpus import stopwords
morph = pymorphy2.MorphAnalyzer()
import pickle

FileIndex= {}
with open("invert_index.pickle","rb") as file:
    FileIndex = pickle.load(file)
def clear_data(data):
    data = re.sub(r'[\W_]+'," ", data)
    data = data.lower().split(" ")
    clear = [morph.parse(i)[0].normal_form for i in data if i not in stopwords.words('russian')]
    return clear

req = input()
clear_req = clear_data(req)
list = []
for word in clear_req:
    if word in FileIndex.keys():
        list.append(FileIndex[word])
        print(word, "Есть в документе")
    else:
        print(word,  "Нет в документах")
if list:
    result = set(list[0])
    for i in list:
        result.intersection(i)
    print(result)
else:
    print("Ни одного документа не найдено")


